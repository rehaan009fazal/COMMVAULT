from flask import Flask, render_template, request, send_file
import os

import boto3
from botocore.exceptions import NoCredentialsError

# Initialize an S3 client
s3 = boto3.client(
    's3',
    aws_access_key_id='AKIAQDVBLQUEM7D7MAEF',
    aws_secret_access_key='XN1N9zBtustVCVsmMSKrIBd7rd6gaxSlLZsO4vt2',
    region_name='ap-south-1'  
)

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'

# Define your routes and functions below

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    email = request.form.get('email')
    filename = request.form.get('filename')
    if email and filename:
        # Create a unique filename based on email and filename
        unique_filename = f'{email}_{filename}'
        # Save the file in the S3 bucket
        uploaded_file = request.files['file']
        if uploaded_file:
            try:
                s3.upload_fileobj(
                    uploaded_file,
                    'm-bucket-09',  
                    unique_filename
                )
                return "File uploaded successfully."
            except NoCredentialsError:
                return "AWS credentials not found or incorrect."
    return "Please provide email and filename."

@app.route('/search', methods=['POST'])
def search():
    email = request.form.get('email')
    search_query = request.form.get('search_query')
    
    if email:
        if not search_query:  # If the search query is empty
            # Retrieve all files associated with the provided email
            matching_files = [file['Key'] for file in s3.list_objects(Bucket='my-bucket009')['Contents'] if email in file['Key']]
        else:
            # Search for files that match both email and search query
            matching_files = [file['Key'] for file in s3.list_objects(Bucket='my-bucket009')['Contents'] if email in file['Key'] and search_query in file['Key']]
        
        return render_template('search_results.html', files=matching_files)
    
    return "Please provide an email address."


@app.route('/download/<file>')
def download(file):
    try:
        obj = s3.get_object(Bucket='my-bucket009', Key=file)
        return send_file(obj['Body'], as_attachment=True, attachment_filename=file)
    except NoCredentialsError:
        return "AWS credentials not found or incorrect."


if __name__ == '__main__':
    app.run(debug=True)




