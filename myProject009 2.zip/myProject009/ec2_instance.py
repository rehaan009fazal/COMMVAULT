import boto3

ec2 = boto3.resource('ec2', region_name='ap-south-1')
s3 = boto3.resource('s3')

# Specify the key pair name
key_pair_name = 'Devkey'

# Create an EC2 instance
instance = ec2.create_instances(
    ImageId='ami-06f621d90fa29f6d0',  # Amazon Linux 2023 AMI
    InstanceType='t2.micro',  
    MinCount=1,
    MaxCount=1,
    KeyName=key_pair_name,  
    TagSpecifications=[
        {
            'ResourceType': 'instance',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': 'M_se_009'
                }
            ]
        }
    ]
)

instance_ip_address = instance[0].public_ip_address

# Create a bucket
bucket = s3.create_bucket(
    Bucket='m-bucket-09',
    CreateBucketConfiguration={
        'LocationConstraint': 'ap-south-1'
    }
)

print('Public IP address of the instance: {}'.format(instance_ip_address))
print('Bucket created: {}'.format(bucket.name))
